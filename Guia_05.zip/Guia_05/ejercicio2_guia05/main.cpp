#include <iostream>
//EJERCICIO 2 TEPAS MAZARIEGO,KENIA STEPHANNIE TM17013



void Pascal(int v[100],int grado,int a);

void Pascal(int v[100],int grado,int x){
    int auxiliar[x+1];
    auxiliar[0]=1;
    auxiliar[x]=1;
    if(x<=grado){

        for (int i = 1; i <x ; ++i) {
            auxiliar[i]=v[i-1]+v[i];
        }
        for (int j = 0; j <=x; ++j) {
            printf("[%i]",auxiliar[j]);
        }
        x=x+1;
        printf("\n");
        Pascal(auxiliar,grado,x);
    }
}

int main() {
    int grado,v[0];
    v[0]=1;
    printf("Ingresar el grado n:\n");
    scanf("%d",&grado);
    Pascal(v,grado,0);
    return 0;
}
