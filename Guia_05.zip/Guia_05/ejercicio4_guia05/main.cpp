#include <iostream>
//EJERCICIO 4 TEPAS MAZARIEGO, KENIA STEPHANNIE TM17013
#define N 3 //dimensión del laberinto
int li[]={1,0,-1,0};
int lj[]={0,1,0,-1};
int matriz[N][N];
int salida=0;

void laberinto(int i,int j){
    //condiciones para los pasos
    if(i<0 || j<0)
        return;
    if (i>=N || j>=N)
        return;
    if(matriz[i][j]==-1)
        return;
    if(matriz[i][j]==1)
        return;
    if(i==0 && j==0){
        salida=1;
        printf("Final del laberinto \n");
        printf("pasaste por: (%d,%d)\n",0,0);
        return;
    }
    matriz[i][j]=1;
    for(int x = 0; x< 4 ; i++){
        laberinto(i+li[x],j+lj[x]);
        if(salida){
            printf("pasaste por: (%d,%d)\n",i,j);
            return;
        }
    }
}
int main() {
printf("Ejercicio 4 \n");
printf("El laberinto es %dx%d\n",N,N);
printf("Ingrese el numero de obstaculos: \n");
int obs;
scanf("%d",&obs);
int i, j;
for( int x =0; x< N;x++ ){
    for(int j=0; j<N;j++){
        matriz[x][j]=0;
    }
}
//ingresa pasos
for(int x=0; x<obs; x++){
    printf("Ingrese el obstaculo %d [0,%d]: \n",x,N-1);
    scanf("%d",&i);
    scanf("%d",&j);
    matriz[i][j]= -1;
}
//muestra camino recorrido
printf("\n");
for(int x=0;x<N;x++){
    for(int y=0;y<N;y++){
        if(matriz[y][x]==-1){
            printf("-");
        }else{
            printf("%d",matriz[y][x]);
        }
    }
    printf("\n");
}
    printf("\n");
    laberinto(N-1,N-1); //llamada de metodo laberinto
    return 0;
}