#include <iostream>
//EJERCICIO1 TEPAS MAZARIEGO, KENIA STEPHANNIE TM17013
//arreglo de digitos
char cod[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','E','F'};
//metodo para base 16
void hexa(int n){
    if(n<16){
        printf("%c",cod[n]);
        return;
    }
    hexa(n/16);
    int c = (n%16);
    printf("%c",cod[c]);
}
//metodo base b
void baseb (int n,int x){
    if(n<x){
        printf("%c",cod[n]);
        return;
    }
    baseb(n/x,x);
    int c= (n%x);
    printf("%c",cod[c]);
}

int main() {
 printf("Ejercicio 1 \n\n");
 printf("Ingrese el numero para cambiarlo de base: \n");
  int n;
  scanf("%d",&n);
 printf("Ingrese la base menor a 10: \n");
  int x;
  scanf("%d",&x);
//mostrar
 printf("Su numero base 16 (hexadecimal) es: ");
  hexa(n);
 printf("\n");
 printf("Su numero base B  es: ");
  baseb(n,x);
 printf("\n");

return 0;
}