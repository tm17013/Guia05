#include <iostream>
//EJERCICIO 3 TEPAS MAZARIEGO KENIA STEPHANNIE TM17013

int MCD(int, int);

// Metodo con recursividad
   int MCD(int m, int n) {

    if (n == 0)
        return m;

    return MCD(n, m%n);
}
int main(){

    int x, y; //numeros a ingresar
    int r;

    printf("Ingrese el valor de M: ");
    scanf("%d", &x);

    printf("Ingrese el valor de N: ");
    scanf("%d", &y);

    // Obtener el resultado.
    if (y > x ){
        r = MCD(y,x);
    } else {
        r = MCD(x,y);
    }
    printf("El MCD de %d y %d es: %d", x, y, r);
    return 0;
}
